#!/usr/bin/env bash

sudo apt-get install texlive-extra-utils   

sudo python3 -m pip install -r ./requirements.txt